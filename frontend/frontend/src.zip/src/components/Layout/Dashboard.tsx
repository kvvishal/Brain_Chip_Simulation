"use client";

import TopBar from "./TopBar";
import LeftPanel from "./LeftPanel";
import RightPanel from "./RightPanel";
import BottomBar from "./BottomBar";

import BrainCanvas from "../Brain/BrainCanvas";

export default function Dashboard() {
  return (
    <div className="h-screen flex flex-col">

        <TopBar/>

            <div className="flex flex-1 overflow-hidden">

        <LeftPanel/>

            <div className="flex-1 p-4">

        <BrainCanvas/>

    </div>

    <RightPanel/>

    </div>

    <BottomBar/>

    </div>
  );
}