"use client";

import { BrainSceneProvider } from "./BrainSceneContext";
import BrainRoot from "./BrainRoot";

export default function Brain() {

    return (

        <BrainSceneProvider>

            <BrainRoot/>

        </BrainSceneProvider>

    );

}