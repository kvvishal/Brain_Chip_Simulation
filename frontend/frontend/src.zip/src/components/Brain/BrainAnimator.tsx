"use client";

import { useFrame } from "@react-three/fiber";
import BrainEngine from "@/components/Brain/BrainEngine";

export default function BrainAnimator(){

    useFrame(()=>{

        // later

        // activity update

        // pulse update

        // EEG update

    });

    return null;

}