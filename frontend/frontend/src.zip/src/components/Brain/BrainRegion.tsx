"use client";

import * as THREE from "three";
import {useFrame}from "@react-three/fiber";
import {useRef} from "react";

type BrainRegionProps = {

    position: THREE.Vector3;

    activity: number;

    color: string;

};

export default function BrainRegion({

    position,

    activity,

    color

}: BrainRegionProps) {

    const meshRef = useRef<THREE.Mesh>(null);
    useFrame(({clock}) => {

        if (!meshRef.current) return;

        const pulse = 0.8 + activity * 0.35;

        const material = meshRef.current.material as THREE.MeshStandardMaterial;

        material.emissiveIntensity = 0.2 + activity * 1.2;

        meshRef.current.scale.setScalar(1);
    });

    return (

        <mesh position={position} ref ={meshRef} renderOrder={10}>

            <sphereGeometry args={[0.035, 20, 20]} />

            <meshStandardMaterial

                color={color}

                metalness={0.65}

                emissive={color}

                emissiveIntensity={2}

                toneMapped = {false}

            />

        </mesh>

    );

}