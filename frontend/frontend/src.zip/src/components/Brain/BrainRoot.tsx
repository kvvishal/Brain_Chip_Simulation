"use client";

import BrainModel from "./BrainModel";
import BrainRegions from "./BrainRegions";
import BrainConnections from "./BrainConnections";
import { useFrame } from "@react-three/fiber";
import { brainEngine } from "./BrainEngine";
import { useEffect } from "react";

export default function BrainRoot() {

    useFrame(() =>{

          brainEngine.update();
        })

    useEffect(() => {

      const timer = setInterval(() => {

        brainEngine.update();

      }, 100);

      return () => clearInterval(timer);
      
    }, []);

    return (
        

        <group>

            <BrainModel />
            
            <BrainConnections />

            <BrainRegions />

        </group>

    );

  }