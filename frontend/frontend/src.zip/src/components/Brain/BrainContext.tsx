"use client";

import {
    createContext,
    useContext,
    useState,
    ReactNode
} from "react";

import * as THREE from "three";

type BrainContextType = {

    points: THREE.Vector3[];

    setPoints: (p: THREE.Vector3[]) => void;

};

const BrainContext = createContext<BrainContextType | null>(null);

export function BrainProvider({

    children

}:{

    children:ReactNode

}){

    const [points,setPoints] = useState<THREE.Vector3[]>([]);

    return(

        <BrainContext.Provider

            value={{

                points,

                setPoints

            }}

        >

            {children}

        </BrainContext.Provider>

    );

}

export function useBrain(){

    const ctx = useContext(BrainContext);

    if(!ctx){

        throw new Error("BrainProvider missing");

    }

    return ctx;

}