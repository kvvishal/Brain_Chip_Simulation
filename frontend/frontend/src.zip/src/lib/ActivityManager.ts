export default class ActivityManager{

    activity:number[]=[];

    update(frame:number[]){

        this.activity=frame;

    }

    get(id:number){

        return this.activity[id]??0;

    }

}