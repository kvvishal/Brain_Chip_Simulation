import * as THREE from "three";

export default class RegionManager{

    points:THREE.Vector3[]=[];

    set(points:THREE.Vector3[]){

        this.points=points;

    }

    get(id:number){

        return this.points[id];

    }

}