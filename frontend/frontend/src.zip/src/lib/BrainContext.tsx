"use client";

import { createContext, useContext, useState } from "react";
import * as THREE from "three";

interface BrainContextType {
  regions: THREE.Vector3[];
  setRegions: (points: THREE.Vector3[]) => void;
}

const BrainContext = createContext<BrainContextType>({
  regions: [],
  setRegions: () => {},
});

export function BrainProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [regions, setRegions] = useState<THREE.Vector3[]>([]);

  return (
    <BrainContext.Provider value={{ regions, setRegions }}>
      {children}
    </BrainContext.Provider>
  );
}

export function useBrain() {
  return useContext(BrainContext);
}