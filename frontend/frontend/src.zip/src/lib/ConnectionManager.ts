export default class ConnectionManager{

    connections:number[][]=[];

    constructor(c:number[][]){

        this.connections=c;

    }

}