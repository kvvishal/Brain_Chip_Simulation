import * as THREE from "three";
import { MeshSurfaceSampler } from "three/examples/jsm/math/MeshSurfaceSampler.js";

export function sampleBrainRegions(mesh: THREE.Mesh, count = 96) {
  const sampler = new MeshSurfaceSampler(mesh).build();

  const position = new THREE.Vector3();
  const normal = new THREE.Vector3();

  const regions = [];

  for (let i = 0; i < count; i++) {

    sampler.sample(position, normal);

    // Push slightly inside the brain
    position.addScaledVector(normal, -2);

    regions.push({
      id: i,
      position: [
        position.x,
        position.y,
        position.z,
      ],
    });
  }

  return regions;
}