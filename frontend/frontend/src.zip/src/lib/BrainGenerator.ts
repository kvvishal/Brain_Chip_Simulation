import * as THREE from "three";

export interface RegionPosition {
  id: number;
  position: [number, number, number];
}

export function generateBrainRegions(count = 96): RegionPosition[] {
  const regions: RegionPosition[] = [];

  const radiusX = 1.7;
  const radiusY = 1.2;
  const radiusZ = 1.5;

  while (regions.length < count) {

    const x = (Math.random() * 2 - 1) * radiusX;
    const y = (Math.random() * 2 - 1) * radiusY;
    const z = (Math.random() * 2 - 1) * radiusZ;

    const inside =
      (x * x) / (radiusX * radiusX) +
      (y * y) / (radiusY * radiusY) +
      (z * z) / (radiusZ * radiusZ);

    if (inside <= 1) {
      regions.push({
        id: regions.length,
        position: [x, y, z],
      });
    }
  }

  return regions;
}